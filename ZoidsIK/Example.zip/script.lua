vanilla_model.PLAYER:setVisible(false)
models.model:primaryTexture("SKIN")

local ik = require("ZoidsIK")

local chain = ik.new({
        models.chain.Skull.segment1,
        models.chain.Skull.segment1.segment2,
        models.chain.Skull.segment1.segment2.segment3,
        models.chain.Skull.segment1.segment2.segment3.segment4,
    }, {
        25, 25, 25, 25,
    },
    "example")

local function getEntities(min, max)
    local e = {}

    raycast:entity(min, max, function(hit)
        e[#e + 1] = hit
        return false
    end)

    return e
end

local function nearestEntity(point, radius)
    local best = math.huge
    local entity
    for _, e in pairs(getEntities(point - radius, point + radius)) do
        local dist = (e:getPos() - point):lengthSquared()
        if dist < best then
            best = dist
            entity = e
        end
    end
    return entity
end

local target = vectors.vec3(0, 0, 0)
function events.skull_render(_, block, _, _, ctx)
    if ctx == "BLOCK" then
        local entity = nearestEntity(block:getPos() + vectors.vec3(0.5, 0.2, 0.5), 10)
        if entity ~= nil then
            if chain:isInReach(entity:getPos()) then
                target = math.lerp(target, entity:getPos(), 0.1)
            else
                target = math.lerp(target, block:getPos() + vectors.vec3(0.5, 6.5, 0.5), 0.1)
            end
        else
            target = math.lerp(target, block:getPos() + vectors.vec3(0.5, 6.5, 0.5), 0.1)
        end
        chain:solve(block:getPos() + vectors.vec3(0.5, 0.2, 0.5),
            block:getPos() + vectors.vec3(0.5, 6.25, 0.5), 1)
        --- 20 iterations is overkill in most cases. 10 should be fine usually.
        chain:solve(block:getPos() + vectors.vec3(0.5, 0.2, 0.5), target, 20)
    end
end
